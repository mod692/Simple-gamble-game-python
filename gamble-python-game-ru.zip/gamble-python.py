import random
import pygame

pygame.mixer.init()

def проиграть_звук(файл):
    pygame.mixer.music.load(файл)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pass

баланс = 100

while True:
    ставка = int(input(f"У тебя есть €{баланс}. Сколько хочешь поставить? "))

    if ставка > баланс:
        print("Недостаточно денег!")
        continue

    цвет = random.choice(["чёрный", "красный"])
    попытка = input("Угадай цвет ('чёрный' или 'красный'): ").lower()

    if попытка == цвет:
        print("Угадал! Ты получаешь двойную ставку.")
        баланс += ставка * 2
        проиграть_звук("jackpot2.mp3")
    else:
        print(f"Неверно! Правильный ответ: {цвет}. Ты теряешь свою ставку.")
        баланс -= ставка
        проиграть_звук("wrong1.mp3")

    if баланс <= 0:
        print("У тебя больше нет денег.")
        break

    снова = input("Хочешь сыграть ещё раз? (да/нет): ").lower()
    if снова != "да":
        print(f"Ты уходишь с €{баланс}")
        if баланс <= 150:
            print("Ты плохой игрок")
        else:
            print("Ты профессиональный игрок")
        break
