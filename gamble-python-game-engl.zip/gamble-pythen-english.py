import random
import pygame

pygame.mixer.init()

def play_sound(file):
    pygame.mixer.music.load(file)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pass

balance = 100

while True:
    bet = int(input(f"You have €{balance}. How much do you want to bet? "))

    if bet > balance:
        print("You don't have enough money!")
        continue

    color = random.choice(["black", "red"])
    guess = input("Guess the color ('black' or 'red'): ").lower()

    if guess == color:
        print("Correct! You win double your bet.")
        balance += bet * 2
        play_sound("jackpot2.mp3")
    else:
        print(f"Wrong! The correct color was: {color}. You lose your bet.")
        balance -= bet
        play_sound("wrong1.mp3")

    if balance <= 0:
        print("You have no money left.")
        break

    again = input("Do you want to play again? (yes/no): ").lower()
    if again != "yes":
        print(f"You are leaving with €{balance}")
        if balance <= 150:
            print("You're a bad gambler")
        else:
            print("You're a professional gambler")
        break